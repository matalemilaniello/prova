曙宝 Shubao · meme kit

Contenuto / Contents
- stickers/        PNG 800 px, sfondo trasparente / transparent background
- telegram/        PNG 512 px pronti per @Stickers su Telegram / ready for Telegram @Stickers
- x-header-1500x500.jpg   banner per X / X header
- og-*.jpg         immagini 1200x630 per i post / post images
- pfp-frame-1024.png      cornice per la foto profilo / profile picture frame
- logo-512.png     icona / icon

Le illustrazioni sono opere originali create con l'aiuto dell'AI per la community di 曙宝.
Puoi usarle gratis per meme e post non commerciali sul progetto. Non usarle per spacciarti
per i canali ufficiali, per Everland o per altri, né in contenuti ingannevoli o illeciti.
Sono fornite così come sono, senza alcuna garanzia.
The illustrations are original, AI-assisted artwork made for the 曙宝 community. You may use
them free of charge for non-commercial memes and posts about the project. Do not use them to
impersonate the official channels, Everland or anyone else, or in misleading or unlawful
content. Provided as is, without any warranty.

曙宝 is a fan-made memecoin, not affiliated with Everland or Samsung C&T. Not financial advice.
Terms: https://shubaocto.com/legal/

Contratto ufficiale / Official contract (BNB Chain):
0x7E15837DaF327b65f571a008B2D5Dd6C5E407777
Sito / Website: https://shubaocto.com
