曙宝 Shubao · meme kit

Contenuto / Contents
- stickers/        PNG 800 px, sfondo trasparente / transparent background
- telegram/        PNG 512 px pronti per @Stickers su Telegram / ready for Telegram @Stickers
- x-header-1500x500.jpg   banner per X / X header
- og-*.jpg         immagini 1200x630 per i post / post images
- pfp-frame-1024.png      cornice per la foto profilo / profile picture frame
- logo-512.png     icona / icon

Le illustrazioni sono opere originali create per la community di 曙宝.
Usale liberamente per meme e post sul progetto. Non usarle per spacciarti per Everland
o per altri progetti.
The illustrations are original artwork made for the 曙宝 community. Use them freely for
memes and posts about the project. Don't use them to impersonate Everland or other projects.

Contratto ufficiale / Official contract (BNB Chain):
0x7E15837DaF327b65f571a008B2D5Dd6C5E407777
Sito / Website: https://shubao-9rh.pages.dev
